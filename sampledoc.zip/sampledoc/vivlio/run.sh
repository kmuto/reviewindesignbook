#!/bin/sh
(cd vivlio && compass compile)
vivliostyle-formatter sample.html
