﻿// 最初のJavaScriptプログラム
var myDocument = app.activeDocument;
alert(myDocument.name);
